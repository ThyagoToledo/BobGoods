package com.example.bobgoods

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.core.content.ContextCompat
import java.util.*

class DrawingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var drawPath: Path = Path()
    private var drawPaint: Paint = Paint()
    private var canvasPaint: Paint = Paint(Paint.DITHER_FLAG)
    private var drawCanvas: Canvas? = null
    private var canvasBitmap: Bitmap? = null
    
    private var currentColor: Int = Color.RED
    private val brushSize = 15f
    private var currentImageResource: Int = R.drawable.primeira_pintura
    private var paintMode: PaintMode = PaintMode.BUCKET_FILL

    // Enum para diferentes modos de pintura
    enum class PaintMode {
        BRUSH,
        BUCKET_FILL
    }

    init {
        setupDrawing()
    }

    private fun setupDrawing() {
        drawPaint.color = currentColor
        drawPaint.isAntiAlias = true
        drawPaint.strokeWidth = brushSize
        drawPaint.style = Paint.Style.STROKE
        drawPaint.strokeJoin = Paint.Join.ROUND
        drawPaint.strokeCap = Paint.Cap.ROUND
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        canvasBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        drawCanvas = Canvas(canvasBitmap!!)
        
        // Carrega a imagem selecionada como fundo
        loadSelectedImage()
    }

    private fun loadSelectedImage() {
        // Limpa o canvas primeiro
        drawCanvas?.drawColor(Color.WHITE)

        try {
            if (currentImageResource == R.drawable.primeira_pintura) {
                // Carrega a imagem bitmap (foto real)
                val drawable = ContextCompat.getDrawable(context, currentImageResource)
                drawable?.let {
                    // Define os bounds para centralizar a imagem
                    val drawableWidth = width - 40
                    val drawableHeight = height - 40
                    val left = 20
                    val top = 20

                    it.setBounds(left, top, left + drawableWidth, top + drawableHeight)
                    it.draw(drawCanvas!!)
                }
            } else {
                // Carrega o drawable vetorial
                val drawable = ContextCompat.getDrawable(context, currentImageResource)
                drawable?.let {
                    val drawableWidth = width - 40
                    val drawableHeight = height - 40
                    val left = 20
                    val top = 20

                    it.setBounds(left, top, left + drawableWidth, top + drawableHeight)
                    it.draw(drawCanvas!!)
                }
            }
        } catch (e: Exception) {
            // Se houver erro ao carregar a imagem, desenha uma silhueta simples
            drawBobbieSilhouette()
        }
    }

    private fun drawBobbieSilhouette() {
        val paint = Paint().apply {
            color = Color.LTGRAY
            style = Paint.Style.STROKE
            strokeWidth = 3f
            pathEffect = DashPathEffect(floatArrayOf(10f, 5f), 0f)
        }

        val centerX = width / 2f
        val centerY = height / 2f

        // Cabeça
        drawCanvas?.drawCircle(centerX, centerY - 100f, 80f, paint)

        // Corpo
        val bodyRect = RectF(centerX - 60f, centerY - 20f, centerX + 60f, centerY + 150f)
        drawCanvas?.drawRoundRect(bodyRect, 20f, 20f, paint)

        // Braços
        drawCanvas?.drawLine(centerX - 60f, centerY + 30f, centerX - 120f, centerY + 80f, paint)
        drawCanvas?.drawLine(centerX + 60f, centerY + 30f, centerX + 120f, centerY + 80f, paint)

        // Pernas
        drawCanvas?.drawLine(centerX - 30f, centerY + 150f, centerX - 30f, centerY + 220f, paint)
        drawCanvas?.drawLine(centerX + 30f, centerY + 150f, centerX + 30f, centerY + 220f, paint)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawBitmap(canvasBitmap!!, 0f, 0f, canvasPaint)
        canvas.drawPath(drawPath, drawPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val touchX = event.x
        val touchY = event.y

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                if (paintMode == PaintMode.BUCKET_FILL) {
                    // Modo balde de tinta - preenche área
                    bucketFill(touchX.toInt(), touchY.toInt(), currentColor)
                } else {
                    // Modo pincel normal
                    drawPath.moveTo(touchX, touchY)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (paintMode == PaintMode.BRUSH) {
                    drawPath.lineTo(touchX, touchY)
                }
            }
            MotionEvent.ACTION_UP -> {
                if (paintMode == PaintMode.BRUSH) {
                    drawCanvas?.drawPath(drawPath, drawPaint)
                    drawPath.reset()
                }
            }
            else -> return false
        }
        invalidate()
        return true
    }

    private fun bucketFill(x: Int, y: Int, newColor: Int) {
        if (canvasBitmap == null || x < 0 || y < 0 || x >= width || y >= height) return

        val targetColor = canvasBitmap!!.getPixel(x, y)

        // Se a cor alvo é igual à nova cor, não precisa fazer nada
        if (targetColor == newColor) return

        // Verifica se é uma cor de linha/contorno (preto ou muito escuro)
        // Não pinta sobre as linhas para manter os contornos
        if (isContourColor(targetColor)) return

        // Algoritmo flood fill otimizado com limite de tolerância
        val width = canvasBitmap!!.width
        val height = canvasBitmap!!.height
        val pixels = IntArray(width * height)
        canvasBitmap!!.getPixels(pixels, 0, width, 0, 0, width, height)

        val queue = ArrayDeque<Point>()
        val visited = BooleanArray(pixels.size)
        queue.offer(Point(x, y))

        var pixelsChanged = 0
        val maxPixels = width * height / 4 // Limite para evitar travamentos

        while (queue.isNotEmpty() && pixelsChanged < maxPixels) {
            val point = queue.poll()
            val px = point.x
            val py = point.y

            // Verifica limites
            if (px < 0 || px >= width || py < 0 || py >= height) continue

            val index = py * width + px

            // Se já foi visitado ou não é a cor alvo, pula
            if (visited[index] || !isSimilarColor(pixels[index], targetColor)) continue

            // Marca como visitado e pinta
            visited[index] = true
            pixels[index] = newColor
            pixelsChanged++

            // Adiciona pixels adjacentes na fila
            queue.offer(Point(px + 1, py))
            queue.offer(Point(px - 1, py))
            queue.offer(Point(px, py + 1))
            queue.offer(Point(px, py - 1))
        }

        // Atualiza o bitmap apenas uma vez ao final
        canvasBitmap!!.setPixels(pixels, 0, width, 0, 0, width, height)
    }

    private fun isContourColor(color: Int): Boolean {
        val red = Color.red(color)
        val green = Color.green(color)
        val blue = Color.blue(color)

        // Considera cores escuras (contornos) como não pintáveis
        val brightness = (red + green + blue) / 3
        return brightness < 50 // Pixels muito escuros são considerados contorno
    }

    private fun isSimilarColor(color1: Int, color2: Int): Boolean {
        val tolerance = 30 // Tolerância para cores similares

        val r1 = Color.red(color1)
        val g1 = Color.green(color1)
        val b1 = Color.blue(color1)

        val r2 = Color.red(color2)
        val g2 = Color.green(color2)
        val b2 = Color.blue(color2)

        return Math.abs(r1 - r2) <= tolerance &&
               Math.abs(g1 - g2) <= tolerance &&
               Math.abs(b1 - b2) <= tolerance
    }

    fun setColor(color: Int) {
        currentColor = color
        drawPaint.color = currentColor
    }

    fun loadImage(imageResource: Int) {
        currentImageResource = imageResource
        if (canvasBitmap != null) {
            loadSelectedImage()
            invalidate()
        }
    }

    fun setPaintMode(mode: PaintMode) {
        paintMode = mode
    }

    fun clearCanvas() {
        loadSelectedImage()
        invalidate()
    }

    fun getBitmap(): Bitmap? {
        return canvasBitmap
    }
}
