package com.example.bobgoods.data

import kotlinx.coroutines.flow.Flow

class BobbieFigureRepository(
    private val figureDao: BobbieFigureDao,
    private val progressDao: UserProgressDao,
    private val achievementDao: AchievementDao
) {

    fun getAllFigures(): Flow<List<BobbieFigure>> = figureDao.getAllFigures()

    fun getFiguresByCategory(category: String): Flow<List<BobbieFigure>> =
        figureDao.getFiguresByCategory(category)

    suspend fun getFigureById(id: Int): BobbieFigure? = figureDao.getFigureById(id)

    fun getAllProgress(): Flow<List<UserProgress>> = progressDao.getAllProgress()

    suspend fun getProgressByFigureId(figureId: Int): UserProgress? =
        progressDao.getProgressByFigureId(figureId)

    suspend fun updateProgress(progress: UserProgress) {
        progressDao.insertOrUpdateProgress(progress)
        checkAchievements()
    }

    fun getAllAchievements(): Flow<List<Achievement>> = achievementDao.getAllAchievements()

    fun getUnlockedAchievements(): Flow<List<Achievement>> = achievementDao.getUnlockedAchievements()

    private suspend fun checkAchievements() {
        val completedCount = progressDao.getCompletedCount()
        val achievements = achievementDao.getAllAchievements()

        // Lógica para desbloquear conquistas baseada no progresso
        // Isso será implementado conforme necessário
    }

    suspend fun unlockAchievement(achievementId: Int) {
        val achievements = achievementDao.getAllAchievements()
        // Implementar lógica de desbloqueio
    }
}
