package com.example.bobgoods.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

@Database(
    entities = [BobbieFigure::class, UserProgress::class, Achievement::class],
    version = 1,
    exportSchema = false
)
abstract class BobbieFigureDatabase : RoomDatabase() {
    abstract fun bobbieFigureDao(): BobbieFigureDao
    abstract fun userProgressDao(): UserProgressDao
    abstract fun achievementDao(): AchievementDao

    companion object {
        @Volatile
        private var INSTANCE: BobbieFigureDatabase? = null

        fun getDatabase(
            context: Context,
            scope: CoroutineScope
        ): BobbieFigureDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BobbieFigureDatabase::class.java,
                    "bobbie_figure_database"
                )
                .addCallback(BobbieFigureDatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class BobbieFigureDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch {
                    populateDatabase(database.bobbieFigureDao(), database.achievementDao())
                }
            }
        }

        suspend fun populateDatabase(figureDao: BobbieFigureDao, achievementDao: AchievementDao) {
            // Dados iniciais dos Bobbie Goods
            val figures = listOf(
                BobbieFigure(1, "Bobbie Unicórnio", "bobbie_unicorn", "Fantasia", 2),
                BobbieFigure(2, "Bobbie Cachorro", "bobbie_dog", "Animais", 1),
                BobbieFigure(3, "Bobbie Gato", "bobbie_cat", "Animais", 1),
                BobbieFigure(4, "Bobbie Princesa", "bobbie_princess", "Fantasia", 3),
                BobbieFigure(5, "Bobbie Pirata", "bobbie_pirate", "Aventura", 3),
                BobbieFigure(6, "Bobbie Astronauta", "bobbie_astronaut", "Aventura", 4),
                BobbieFigure(7, "Bobbie Fada", "bobbie_fairy", "Fantasia", 2),
                BobbieFigure(8, "Bobbie Dinossauro", "bobbie_dinosaur", "Aventura", 2),
                BobbieFigure(9, "Bobbie Sereia", "bobbie_mermaid", "Fantasia", 4),
                BobbieFigure(10, "Bobbie Super-Herói", "bobbie_superhero", "Aventura", 5)
            )
            figureDao.insertFigures(figures)

            // Conquistas iniciais
            val achievements = listOf(
                Achievement(1, "Primeira Pintura", "Complete sua primeira figura", "achievement_first", false, null, "complete_any_1"),
                Achievement(2, "Explorador de Animais", "Complete todas as figuras de animais", "achievement_animals", false, null, "complete_category_animais"),
                Achievement(3, "Mundo da Fantasia", "Complete todas as figuras de fantasia", "achievement_fantasy", false, null, "complete_category_fantasia"),
                Achievement(4, "Aventureiro", "Complete todas as figuras de aventura", "achievement_adventure", false, null, "complete_category_aventura"),
                Achievement(5, "Mestre Pintor", "Complete todas as figuras", "achievement_master", false, null, "complete_all"),
                Achievement(6, "Velocista", "Complete uma figura em menos de 10 minutos", "achievement_speed", false, null, "complete_under_10min"),
                Achievement(7, "Perseverança", "Complete uma figura difícil (nível 4+)", "achievement_hard", false, null, "complete_difficulty_4plus")
            )
            achievementDao.insertAchievements(achievements)
        }
    }
}
