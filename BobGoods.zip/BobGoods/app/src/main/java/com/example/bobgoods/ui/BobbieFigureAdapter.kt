package com.example.bobgoods.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.bobgoods.R
import com.example.bobgoods.data.BobbieFigure
import com.example.bobgoods.data.UserProgress

class BobbieFigureAdapter(
    private val onItemClick: (BobbieFigure) -> Unit
) : ListAdapter<BobbieFigureWithProgress, BobbieFigureAdapter.ViewHolder>(DiffCallback()) {

    private var progressList: List<UserProgress> = emptyList()

    fun updateProgress(progress: List<UserProgress>) {
        progressList = progress
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_bobbie_figure, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item.figure, item.progress, onItemClick)
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val figureImageView: ImageView = itemView.findViewById(R.id.figureImageView)
        private val figureNameText: TextView = itemView.findViewById(R.id.figureNameText)
        private val figureCategoryText: TextView = itemView.findViewById(R.id.figureCategoryText)
        private val difficultyLayout: LinearLayout = itemView.findViewById(R.id.difficultyLayout)
        private val starsLayout: LinearLayout = itemView.findViewById(R.id.starsLayout)
        private val progressBar: ProgressBar = itemView.findViewById(R.id.progressBar)
        private val progressText: TextView = itemView.findViewById(R.id.progressText)
        private val completedIcon: ImageView = itemView.findViewById(R.id.completedIcon)

        fun bind(
            figure: BobbieFigure,
            progress: UserProgress?,
            onItemClick: (BobbieFigure) -> Unit
        ) {
            figureNameText.text = figure.name
            figureCategoryText.text = figure.category

            // Configura as estrelas de dificuldade
            starsLayout.removeAllViews()
            for (i in 1..5) {
                val star = ImageView(itemView.context)
                star.layoutParams = LinearLayout.LayoutParams(24, 24).apply {
                    marginEnd = 4
                }
                if (i <= figure.difficulty) {
                    star.setImageResource(android.R.drawable.btn_star_big_on)
                } else {
                    star.setImageResource(android.R.drawable.btn_star_big_off)
                }
                starsLayout.addView(star)
            }

            // Configura o progresso
            val progressPercentage = progress?.completionPercentage ?: 0
            progressBar.progress = progressPercentage
            progressText.text = itemView.context.getString(R.string.progress_completed, progressPercentage)

            // Mostra ícone de conclusão se completado
            completedIcon.visibility = if (progress?.isCompleted == true) {
                View.VISIBLE
            } else {
                View.GONE
            }

            // Configura a imagem da figura (placeholder por enquanto)
            figureImageView.setImageResource(R.drawable.figure_placeholder)

            // Configura o click
            itemView.setOnClickListener {
                onItemClick(figure)
            }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<BobbieFigureWithProgress>() {
        override fun areItemsTheSame(
            oldItem: BobbieFigureWithProgress,
            newItem: BobbieFigureWithProgress
        ): Boolean {
            return oldItem.figure.id == newItem.figure.id
        }

        override fun areContentsTheSame(
            oldItem: BobbieFigureWithProgress,
            newItem: BobbieFigureWithProgress
        ): Boolean {
            return oldItem == newItem
        }
    }
}

data class BobbieFigureWithProgress(
    val figure: BobbieFigure,
    val progress: UserProgress?
)
