package com.example.bobgoods.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bobbie_figures")
data class BobbieFigure(
    @PrimaryKey
    val id: Int,
    val name: String,
    val imageResource: String,
    val category: String,
    val difficulty: Int = 1 // 1-5 níveis de dificuldade
)

@Entity(tableName = "user_progress")
data class UserProgress(
    @PrimaryKey
    val figureId: Int,
    val isCompleted: Boolean = false,
    val completionPercentage: Int = 0,
    val timeSpent: Long = 0L, // em milissegundos
    val lastAccessTime: Long = System.currentTimeMillis(),
    val coloredPixels: String = "" // JSON string dos pixels coloridos
)

@Entity(tableName = "achievements")
data class Achievement(
    @PrimaryKey
    val id: Int,
    val title: String,
    val description: String,
    val iconResource: String,
    val isUnlocked: Boolean = false,
    val unlockedAt: Long? = null,
    val requirement: String // ex: "complete_figure_1", "complete_all_easy", etc.
)
