package com.example.bobgoods.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BobbieFigureDao {
    @Query("SELECT * FROM bobbie_figures")
    fun getAllFigures(): Flow<List<BobbieFigure>>

    @Query("SELECT * FROM bobbie_figures WHERE id = :id")
    suspend fun getFigureById(id: Int): BobbieFigure?

    @Query("SELECT * FROM bobbie_figures WHERE category = :category")
    fun getFiguresByCategory(category: String): Flow<List<BobbieFigure>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFigures(figures: List<BobbieFigure>)
}

@Dao
interface UserProgressDao {
    @Query("SELECT * FROM user_progress")
    fun getAllProgress(): Flow<List<UserProgress>>

    @Query("SELECT * FROM user_progress WHERE figureId = :figureId")
    suspend fun getProgressByFigureId(figureId: Int): UserProgress?

    @Query("SELECT COUNT(*) FROM user_progress WHERE isCompleted = 1")
    suspend fun getCompletedCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateProgress(progress: UserProgress)

    @Update
    suspend fun updateProgress(progress: UserProgress)
}

@Dao
interface AchievementDao {
    @Query("SELECT * FROM achievements")
    fun getAllAchievements(): Flow<List<Achievement>>

    @Query("SELECT * FROM achievements WHERE isUnlocked = 1")
    fun getUnlockedAchievements(): Flow<List<Achievement>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAchievements(achievements: List<Achievement>)

    @Update
    suspend fun updateAchievement(achievement: Achievement)
}
