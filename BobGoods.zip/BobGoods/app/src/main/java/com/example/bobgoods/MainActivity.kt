package com.example.bobgoods

import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var drawingView: DrawingView
    private lateinit var btnClear: Button
    private lateinit var btnSave: Button
    private lateinit var btnToggleMode: Button
    private lateinit var colorButtons: List<Button>
    private lateinit var imageCard1: CardView
    private lateinit var imageCard2: CardView

    private var currentMode = DrawingView.PaintMode.BUCKET_FILL

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initializeViews()
        setupImageGallery()
        setupColorButtons()
        setupControlButtons()

        // Define modo balde de tinta por padrão
        drawingView.setPaintMode(currentMode)
        updateModeButtonText()
    }

    private fun initializeViews() {
        drawingView = findViewById(R.id.drawingView)
        btnClear = findViewById(R.id.btnClear)
        btnSave = findViewById(R.id.btnSave)
        btnToggleMode = findViewById(R.id.btnToggleMode)
        imageCard1 = findViewById(R.id.imageCard1)
        imageCard2 = findViewById(R.id.imageCard2)

        colorButtons = listOf(
            findViewById(R.id.colorRed),
            findViewById(R.id.colorBlue),
            findViewById(R.id.colorYellow),
            findViewById(R.id.colorGreen),
            findViewById(R.id.colorPurple),
            findViewById(R.id.colorBrown)
        )
    }

    private fun setupImageGallery() {
        // Configura o clique na primeira imagem (foto real)
        imageCard1.setOnClickListener {
            drawingView.loadImage(R.drawable.primeira_pintura)
            Toast.makeText(this, "Primeira Pintura selecionada! Use o balde de tinta!", Toast.LENGTH_SHORT).show()

            // Destaque visual da imagem selecionada
            resetImageSelection()
            imageCard1.cardElevation = 8f
            imageCard1.scaleX = 1.05f
            imageCard1.scaleY = 1.05f
        }

        // Configura o clique na segunda imagem (desenho vetorial)
        imageCard2.setOnClickListener {
            drawingView.loadImage(R.drawable.bobbie_farmer)
            Toast.makeText(this, "Fazendeiro Bobbie selecionado! Use o balde de tinta!", Toast.LENGTH_SHORT).show()

            // Destaque visual da imagem selecionada
            resetImageSelection()
            imageCard2.cardElevation = 8f
            imageCard2.scaleX = 1.05f
            imageCard2.scaleY = 1.05f
        }

        // Carrega a primeira imagem por padrão
        drawingView.loadImage(R.drawable.primeira_pintura)
        imageCard1.cardElevation = 8f
        imageCard1.scaleX = 1.05f
        imageCard1.scaleY = 1.05f
    }

    private fun resetImageSelection() {
        // Remove destaque de todos os cards
        imageCard1.cardElevation = 4f
        imageCard1.scaleX = 1.0f
        imageCard1.scaleY = 1.0f

        imageCard2.cardElevation = 4f
        imageCard2.scaleX = 1.0f
        imageCard2.scaleY = 1.0f
    }

    private fun setupColorButtons() {
        val colors = listOf(
            Color.parseColor("#E17055"), // Vermelho
            Color.parseColor("#74B9FF"), // Azul
            Color.parseColor("#FDCB6E"), // Amarelo
            Color.parseColor("#00B894"), // Verde
            Color.parseColor("#A29BFE"), // Roxo
            Color.parseColor("#8D4004")  // Marrom
        )

        colorButtons.forEachIndexed { index, button ->
            button.setOnClickListener {
                drawingView.setColor(colors[index])
                highlightSelectedColor(button)
                val colorNames = listOf("Vermelho", "Azul", "Amarelo", "Verde", "Roxo", "Marrom")
                Toast.makeText(this, "${colorNames[index]} selecionado! Toque na área para pintar!", Toast.LENGTH_SHORT).show()
            }
        }

        // Seleciona a primeira cor por padrão
        drawingView.setColor(colors[0])
        highlightSelectedColor(colorButtons[0])
    }

    private fun highlightSelectedColor(selectedButton: Button) {
        // Remove destaque de todos os botões
        colorButtons.forEach { button ->
            button.alpha = 0.7f
            button.scaleX = 1.0f
            button.scaleY = 1.0f
        }

        // Destaca o botão selecionado
        selectedButton.alpha = 1.0f
        selectedButton.scaleX = 1.2f
        selectedButton.scaleY = 1.2f
    }

    private fun setupControlButtons() {
        // Botão de alternância de modo
        btnToggleMode.setOnClickListener {
            togglePaintMode()
        }

        btnClear.setOnClickListener {
            drawingView.clearCanvas()
            Toast.makeText(this, "Tela limpa! A imagem original foi restaurada!", Toast.LENGTH_SHORT).show()
        }

        btnSave.setOnClickListener {
            saveDrawing()
        }
    }

    private fun togglePaintMode() {
        currentMode = if (currentMode == DrawingView.PaintMode.BUCKET_FILL) {
            DrawingView.PaintMode.BRUSH
        } else {
            DrawingView.PaintMode.BUCKET_FILL
        }

        drawingView.setPaintMode(currentMode)
        updateModeButtonText()

        val modeText = if (currentMode == DrawingView.PaintMode.BUCKET_FILL) {
            "Modo Balde ativo! Toque nas áreas para preencher."
        } else {
            "Modo Pincel ativo! Desenhe arrastando o dedo."
        }

        Toast.makeText(this, modeText, Toast.LENGTH_SHORT).show()
    }

    private fun updateModeButtonText() {
        if (currentMode == DrawingView.PaintMode.BUCKET_FILL) {
            btnToggleMode.text = "🪣 Balde"
            btnToggleMode.backgroundTintList = getColorStateList(R.color.accent_color)
        } else {
            btnToggleMode.text = "🖌️ Pincel"
            btnToggleMode.backgroundTintList = getColorStateList(R.color.primary_color)
        }
    }

    private fun saveDrawing() {
        val bitmap = drawingView.getBitmap()
        if (bitmap != null) {
            try {
                val filename = "BobbiePintura_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())}.png"
                val file = File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), filename)

                val fileOutputStream = FileOutputStream(file)
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream)
                fileOutputStream.close()

                Toast.makeText(this, "Sua pintura do Bobbie foi salva!\n$filename", Toast.LENGTH_LONG).show()

            } catch (e: Exception) {
                Toast.makeText(this, "Erro ao salvar: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Nada para salvar!", Toast.LENGTH_SHORT).show()
        }
    }
}