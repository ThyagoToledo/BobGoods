package com.example.bobgoods.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.bobgoods.data.BobbieFigure
import com.example.bobgoods.data.BobbieFigureDatabase
import com.example.bobgoods.data.BobbieFigureRepository
import com.example.bobgoods.data.UserProgress
import com.example.bobgoods.data.Achievement
import kotlinx.coroutines.launch

class BobbieFigureViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: BobbieFigureRepository

    val allFigures: LiveData<List<BobbieFigure>>
    val allProgress: LiveData<List<UserProgress>>
    val allAchievements: LiveData<List<Achievement>>

    init {
        val figureDao = BobbieFigureDatabase.getDatabase(application, viewModelScope).bobbieFigureDao()
        val progressDao = BobbieFigureDatabase.getDatabase(application, viewModelScope).userProgressDao()
        val achievementDao = BobbieFigureDatabase.getDatabase(application, viewModelScope).achievementDao()

        repository = BobbieFigureRepository(figureDao, progressDao, achievementDao)

        allFigures = repository.getAllFigures().asLiveData()
        allProgress = repository.getAllProgress().asLiveData()
        allAchievements = repository.getAllAchievements().asLiveData()
    }

    fun getFiguresByCategory(category: String): LiveData<List<BobbieFigure>> {
        return repository.getFiguresByCategory(category).asLiveData()
    }

    suspend fun getFigureById(id: Int): BobbieFigure? {
        return repository.getFigureById(id)
    }

    suspend fun getProgressByFigureId(figureId: Int): UserProgress? {
        return repository.getProgressByFigureId(figureId)
    }

    fun updateProgress(progress: UserProgress) {
        viewModelScope.launch {
            repository.updateProgress(progress)
        }
    }

    fun startPainting(figureId: Int) {
        viewModelScope.launch {
            val existingProgress = repository.getProgressByFigureId(figureId)
            if (existingProgress == null) {
                val newProgress = UserProgress(
                    figureId = figureId,
                    isCompleted = false,
                    completionPercentage = 0,
                    timeSpent = 0L,
                    lastAccessTime = System.currentTimeMillis(),
                    coloredPixels = ""
                )
                repository.updateProgress(newProgress)
            } else {
                val updatedProgress = existingProgress.copy(
                    lastAccessTime = System.currentTimeMillis()
                )
                repository.updateProgress(updatedProgress)
            }
        }
    }
}
